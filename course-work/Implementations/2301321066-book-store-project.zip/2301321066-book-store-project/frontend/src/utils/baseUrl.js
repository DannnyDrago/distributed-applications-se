const getBaseUrl=()=>{

return "https://book-store-app-backend-alpha.vercel.app"


}

export default getBaseUrl;